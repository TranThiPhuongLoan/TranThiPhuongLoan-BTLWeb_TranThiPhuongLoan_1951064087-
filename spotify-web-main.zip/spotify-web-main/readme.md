# Spotify Clone
A front-end clone project of the Spotify website. The project was created using basic css,  js and web components. This is my first big project.

## Preview Link
- [Spotify clone](https://oguz3-projects.web.app/projects/spotify-clone/)

## Tech/Framework Used
* HTML
* CSS
* JavaScript
* Web Components

## Desktop UI

Homepage

![Screenshot](https://oguz3-projects.web.app/projects/spotify_ss/web.PNG)

## Mobile UI

Homepage

![Screenshot](https://oguz3-projects.web.app/projects/spotify_ss/mobil.PNG)